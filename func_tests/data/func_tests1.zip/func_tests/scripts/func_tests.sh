#!/bin/bash

i=1
error=0
num=$(printf "%02d" $i)
while [[ -f "../data/pos_${num}_in.txt" && -f "../data/pos_${num}_out.txt" && -f "../data/args_pos_${num}.txt" ]]
do

    if ./pos_case.sh "../data/pos_${num}_out.txt" "../data/args_pos_${num}.txt"; then

        if [[ $1 != "-s" ]]; then
            echo -e "\033[0;32mTEST ${i}: PASSED"
            echo -ne "\033[0m"
        fi
        
    else

        if [[ $1 == "-s" ]]; then
            error=$((error + 1))        
        else
            error=$((error + 1))
            echo -e "\033[0;31mTEST ${i}: FAILED"
            echo -ne "\033[0m"
        fi

    fi

    i=$((i + 1))
    num=$(printf "%02d" $i)
done

if [[ $1 != "-s" ]]; then
    echo "Negative test: "
fi
i=1
num=$(printf "%02d" $i)
while [[ -f "../data/args_neg_${num}.txt" ]]
do

    if ./neg_case.sh "../data/args_neg_${num}.txt"; then

        if [[ $1 == "-s" ]]; then
            error=$((error + 1))        
        else
            error=$((error + 1))
            echo -e "\033[0;31mTEST ${i}: FAILED"
            echo -ne "\033[0m"
        fi    

    else

        if [[ $1 != "-#!/bin/bash

i=1
error=0
num=$(printf "%02d" $i)
while [[ -f "../data/pos_${num}_in.txt" && -f "../data/pos_${num}_out.txt" && -f "../data/args_pos_${num}.txt" ]]
do

    if ./pos_case.sh "../data/pos_${num}_out.txt" "../data/args_pos_${num}.txt"; then

        if [[ $1 != "-s" ]]; then
            echo -e "\033[0;32mTEST ${i}: PASSED"
            echo -ne "\033[0m"
        fi
        
    else

        if [[ $1 == "-s" ]]; then
            error=$((error + 1))        
        else
            error=$((error + 1))
            echo -e "\033[0;31mTEST ${i}: FAILED"
            echo -ne "\033[0m"
        fi

    fi

    i=$((i + 1))
    num=$(printf "%02d" $i)
done

if [[ $1 != "-s" ]]; then
    echo "Negative test: "
fi
i=1
num=$(printf "%02d" $i)
while [[ -f "../data/args_neg_${num}.txt" ]]
do

    if ./neg_case.sh "../data/args_neg_${num}.txt"; then

        if [[ $1 == "-s" ]]; then
            error=$((error + 1))        
        else
            error=$((error + 1))
            echo -e "\033[0;31mTEST ${i}: FAILED"
            echo -ne "\033[0m"
        fi    

    else

        if [[ $1 != "-s" ]]; then
            echo -e "\033[0;32mTEST ${i}: PASSED"
            echo -ne "\033[0m"
        fi

    fi

    i=$((i + 1))
    num=$(printf "%02d" $i)
done


exit $error