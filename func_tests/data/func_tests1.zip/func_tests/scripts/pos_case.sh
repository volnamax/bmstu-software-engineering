#!/bin/bash

EXP_OUT=$1
FILE_ARGS=""

if [[ $# -gt 1 ]]; then
    FILE_ARGS=$2
    ARGS=$(cat "$FILE_ARGS")
fi

if [[ "$USE_VALGRIND" == "1" ]]; then
    eval "valgrind --track-origins=yes --log-file=valgrind_pos.log -q ../../app.exe $ARGS"
    cat valgrind_pos.log
    rm valgrind_pos.log
else
   #!/bin/bash

EXP_OUT=$1
FILE_ARGS=""

if [[ $# -gt 1 ]]; then
    FILE_ARGS=$2
    ARGS=$(cat "$FILE_ARGS")
fi

if [[ "$USE_VALGRIND" == "1" ]]; then
    eval "valgrind --track-origins=yes --log-file=valgrind_pos.log -q ../../app.exe $ARGS"
    cat valgrind_pos.log
    rm valgrind_pos.log
else
    eval "../../app.exe $ARGS"
fi

if diff out.txt "$EXP_OUT"; then
    exit 0
else
    exit 1
fi
